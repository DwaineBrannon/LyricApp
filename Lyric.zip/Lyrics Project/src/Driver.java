import java.util.ArrayList;
import java.util.Scanner; 
public class Driver {
		//Make ArrayLists for the Decades, Genres, Songs and Artists the app will have 
		// private static ArrayList<Genres> genresList = new ArrayList<Genres>();
		
		private static ArrayList<Songs> songsList = new ArrayList<Songs>();
		
		/*private static ArrayList<Artists> artistsList = new ArrayList<Artists>();
		
		private static ArrayList<Decades> decadesList = new ArrayList<Decades>();
*/
		public static void main(String[] args)  {
			/*
			Scanner userInput = new Scanner(System.in); //Get User input for menu
			// TODO loop through menu choices. If they choose 1, They chose 1970s, then we eliminate any songs not form the 1970s
			// Then we tell the user to choose a Genre. if they choose 1, they choose pop so eliminate any non pop songs
			// The songs we have left are the songs we use for this iteration of the game
			// Choose 5 songs from these songs and these are the ones we use. 
			// Go into a gameplay loop 
			//TODO Main should go thru menu inputs and take in user input
			// Get user menu picks
			// Output song after user picks genre artist etc
			// Output multiple choice's for possible answers based on what the user picked. 
			// If user picked genre, decade AND artist, choose random song from artist.
			// Take user input for their multiple choice pick
			// If user input is correct, respond with correct, else respond "You have two more tries"
			// if user input was wrong update some loop that keeps track of score with --1.
			// If user score <= 0, game over
			// else put another random song in the users category. 
			// If they get every song in category correct, respond yay you win try again?
			//TODO Go through menu. */
			boolean ans = songsList.isEmpty();
			if (ans == true) 
				System.out.println("EMPTY");
			else System.out.println("Not Empty");
			
			
		
		
		
	}

		/* private static void initializeDecadesList() {
			// TODO Auto-generated method stub
		*/ 
	/*}

		/*private static void initializeArtistsList() {
			// TODO Auto-generated method stub */
		
	/* } */ 

		


		/*private static void initializeGenresList() {
			/*each genre should lead to a sub...class? Example Pop should lead to a list of pop songs.
			 OR I could just say if userInput = Pop and userInput = insert decade here then you have a list of every
			 pop song i have in this game from that decade? 
			 But then those songs have to lead to a list of lyrics...and the lyrics have to make multiple choices.
			 Is this inheretence? I am not sure If genres should be a class
			 or if it should be an arrayList.
			*/
			/*genresList.add("Pop");
			genresList.add("Rock");
			genresList.add("R&B");
		*/ 
	/*} */ 
		public static void welcomeMenu() { 									//First Menu to Appear
			System.out.println("Hello, Welcome to Guess the Lyric");
		}
		public static void decadesMenu() {									//Function to choose through the decades
			System.out.println("\n\n");
			System.out.println("Choose a decade or choose 'Random'(1-7)");
			System.out.println("1. 1970's");
			System.out.println("2. 1980's");
			System.out.println("3. 1990's");
			System.out.println("4. 2000's");
			System.out.println("5. 2010's");
			System.out.println("6. 2020's");
			System.out.println("7. Random");
		}
		public static void genresMenu() {									//Function to choose through the genres
			System.out.println("\n\n");
			System.out.println("Now pick a genre, or choose 'Random'");
			System.out.println("Pop");
			System.out.println("Rock");
			System.out.println("R&B");
			System.out.println("Dance");
			System.out.println("Hip Hop/Rap");
		}
		public static void initializeSongsList() {  //Adds the songs to a list 
			Songs badRomance = new Songs("Bad Romance", "Lady Gaga", "2000","Pop");
			songsList.add(badRomance);
			
		}
	

}

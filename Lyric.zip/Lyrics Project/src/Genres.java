/*
public class Genres {
	//instance variables 
	private string Pop;
	private string rock;
}
*/
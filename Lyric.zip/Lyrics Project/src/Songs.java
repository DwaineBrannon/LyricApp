
public class Songs {
	//Instance variables
	private String name;
	private String artist;
	private String releaseDecade;
	private String genre;
		
	//Constructor 
	public Songs(String songName, String songArtist, String releaseDecade, String songGenre) {
		setName(songName);
		setArtist(songArtist);
		setReleaseDate(releaseDecade);
		setGenre(songGenre);
		}
		//getters and setters 
		public String getArtist() {
			return artist;
		}
		public void setArtist(String artist) {
			this.artist = artist;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getReleaseDate() {
			return releaseDecade;
		}
		public void setReleaseDate(String releaseDecade) {
			this.releaseDecade = releaseDecade;
		}
		public String getGenre() {
			return genre;
		}
		public void setGenre(String genre) {
			this.genre = genre;
		}
	
}
